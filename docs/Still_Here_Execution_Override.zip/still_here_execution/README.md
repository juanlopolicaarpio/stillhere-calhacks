# Still Here — execution override for EXISTING repository

This is a targeted implementation directive, **not a replacement starter repo**. Do not extract over source files.

1. Put `CLAUDE_EXECUTE_NOW.md` in the root of your **existing** Still Here repository.
2. Start Claude Code in that repository, ideally on a new git branch.
3. Paste: `Read CLAUDE_EXECUTE_NOW.md fully. Audit the EXISTING repository, launch parallel subagents as specified, implement and integrate, run tests, and deliver the precise credential and live-call handoff. Do not stop after planning. Preserve existing code and original demo.`
4. Provide provider credentials **only in local `.env`**, not in chat. Ask Claude Code to enumerate exact missing environment variables based on code + up-to-date provider docs, without echoing values.
5. Provision a Cartesia-compatible calling number and live webhook HTTPS URL if the preflight says needed. Answer the first live call yourself and test rescheduling/refusal.

This directive preserves the existing full sponsor documentation pack and supersedes any old line claiming SpacetimeDB is optional or conversations may follow a scripted yes/no menu.
